﻿var LITE = {
    Events: {
        INIT: "lite:init",
        ACCEPT: "lite:accept",
        REJECT: "lite:reject",
        SHOW_HIDE: "lite:showHide",
        TRACKING: "lite:tracking",
        CHANGE: "lite:change",
        HOVER_IN: "lite:hover-in",
        HOVER_OUT: "lite:hover-out"
    },
    Commands: {
        TOGGLE_TRACKING: "lite-toggletracking",
        TOGGLE_SHOW: "lite-toggleshow",
        ACCEPT_ALL: "lite-acceptall",
        REJECT_ALL: "lite-rejectall",
        ACCEPT_ONE: "lite-acceptone",
        REJECT_ONE: "lite-rejectone",
        TOGGLE_TOOLTIPS: "lite-toggletooltips"
    }
};